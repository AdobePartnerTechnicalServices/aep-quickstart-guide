echo "Removing old zip file..."
rm aepskill.zip
echo "Creating new zip file..."
zip -r aepskill.zip .